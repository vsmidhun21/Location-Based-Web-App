from django.urls import path
from .views import *
from . import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('', employee_login, name='employee_login'),
    path('Dashboard', employee_dashboard, name='employee_dashboard'),
    path('api/checkin/', checkin, name='checkin'),
    path('checkout/', checkout, name='checkout'),
    # path('SuperAdmin/', views.superadmin_login, name='superadmin_login'),
    # path('SA_Dashboard/', views.superadmin_dashboard, name='superadmin_dashboard'),
    path('SuperAdmin/', superadmin_login, name='superadmin_login'),
    path('SA_Dashboard/', superadmin_dashboard, name='superadmin_dashboard'),
    path('Department', DepartmentView.as_view(),name='department'),
    
]
