# Location Based Web App

Sample web app that gets loation of the user , with that the attendance of the user will be given if the user is within 500 meater range of the office.
